function x = test
global v
x=100*rand(1,1)
v=x
end
