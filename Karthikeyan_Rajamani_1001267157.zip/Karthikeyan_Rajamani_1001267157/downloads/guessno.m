function guessno(a)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
if a==2 
    fprintf('Hello randy!!!\n');
else
    fprintf('Are you tresspassing!!\n');
end

